from django.contrib import admin
from .models import Nomina
# Register your models here.
admin.site.register(Nomina)
